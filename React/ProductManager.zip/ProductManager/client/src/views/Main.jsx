// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
import PersonForm from '../components/PersonForm';

const Main = () => {


  return (
    <PersonForm />
  )
}

export default Main