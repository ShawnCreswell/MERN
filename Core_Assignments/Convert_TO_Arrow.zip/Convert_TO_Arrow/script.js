// function add1 (num) {
//     return num + 1;

// }

// const add1 = function(num){
//     return num + 1;
// }

// const add1 = (num) => {
//     return num + 1;
// }

// const add1 = (num) => num + 1;


const add1 = num => num + 1;