

class Card {
    constructor(name, cost){
        this.name = name;
        this.cost = cost;
    }
}

export default Card